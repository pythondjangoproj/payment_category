from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('AdminApi/', include('Admin_app.urls')),
    path('api/user/', include('IGL_account.urls')),
    path('games/api/', include('games.urls')),
    path('icon/api/', include('icon.urls')),
    path('profile/api/', include('profile_app.urls')),
    path('memberships/', include('payments.urls', namespace='memberships')),
    path('accounts/', include('allauth.urls')),
]
from django.conf import settings
from django.conf.urls.static import static


if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL,
                          document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)

