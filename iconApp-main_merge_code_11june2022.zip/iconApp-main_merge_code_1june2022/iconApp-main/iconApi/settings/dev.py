from .default import *

INSTALLED_APPS += ('icon', 'games', 'IGL_account', 'profile_app', 'Admin_app', 'payments',)
