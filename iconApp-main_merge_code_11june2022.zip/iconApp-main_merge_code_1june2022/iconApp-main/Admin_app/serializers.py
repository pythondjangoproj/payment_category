"""Import required module"""
from rest_framework import serializers
from IGL_account.models import User


class AdminLoginSerializer(serializers.ModelSerializer):
    """ A class AdminLoginSerializer Serializer is used for  AdminLogin Model """
    email = serializers.EmailField(max_length=255)

    class Meta:
        model = User
        fields = ['email', 'password']


class UserOtpSerializer(serializers.ModelSerializer):
    """ create UserOtpSerializer for sending otp to mail"""
    email = serializers.EmailField(max_length=255)

    class Meta:
        model = User
        fields = ['email', ]


class AdminProfileSerializer(serializers.ModelSerializer):
    """ create AdminProfileSerializer for serialized admin profile details"""
    groups = serializers.SerializerMethodField()

    class Meta:
        """ Metaclass is used for changed the behaviour of Your User Model fields"""
        model = User
        fields = ['id', 'last_login', 'is_superuser', 'is_staff', 'is_active', 'date_joined', 'first_name', 'last_name',
                  'mobile_number', 'IGL_Username', 'is_varified', 'terms_and_condition_agreement',
                  'code_of_conduct_agreement', 'email', 'profile_image', 'groups']

    def get_groups(self, obj):
        group = obj.groups.all()
        for name in group:
            return str(name)
