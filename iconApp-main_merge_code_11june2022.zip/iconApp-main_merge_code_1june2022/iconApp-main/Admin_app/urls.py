from django.urls import path
from Admin_app.views import UserOtpView, AdminLoginView, AdminProfileView


urlpatterns = [
    path('admin_login/', AdminLoginView.as_view(), name='admin_login'),
    path('otp/', UserOtpView.as_view(), name='otp'),
    path('admin_profile/', AdminProfileView.as_view(), name='admin_profile'),

]
